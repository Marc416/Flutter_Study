## [1.0.0] - 26th March 2020

- Created the platform interface of the Location plugin in order to support Web and macOS (huge thanks to long1eu)
