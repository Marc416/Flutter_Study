## 1.0.0 26th March 2020

- First release of the Web platform of the Location plugin (huge thanks to long1eu)
